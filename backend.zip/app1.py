from flask import Flask, request, jsonify
import mysql.connector
import nltk
from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords
from datetime import datetime, timedelta
from flask_cors import CORS

app = Flask(__name__)
CORS(app)  
db_config = {
    "host": "localhost",
    "user": "root",
    "password": "",
    "database": "lakshmi"
}

nltk.data.path.append('D:/lakshmi/packages/nltk_data/')
nltk.download('punkt')
nltk.download('stopwords')
stop_words = set(stopwords.words("english"))

def connect_to_db():
    return mysql.connector.connect(**db_config)

def parse_query(query):
    tokens = word_tokenize(query)
    filtered_tokens = [token.lower() for token in tokens if token.lower() not in stop_words or token.lower() in ["most", "not"]]
    
    print("Filtered tokens:", filtered_tokens)
    
    if "increased" in filtered_tokens and "most" in filtered_tokens:
        date = extract_date(filtered_tokens)
        return get_stock_increased_most(date) if date else {"error": "Invalid date format date format should be 05Dec2024"}
    elif "most" in filtered_tokens and "traded" in filtered_tokens:
        if "week" in filtered_tokens:
            return get_most_traded_stock("week")
        elif "month" in filtered_tokens:
            return get_most_traded_stock("month")
    elif "not" in filtered_tokens and "traded" in filtered_tokens and "week" in filtered_tokens:
        return get_not_traded_stocks("week")
    elif "decreased" in filtered_tokens and "most" in filtered_tokens:
        date = extract_date(filtered_tokens)
        return get_stock_decreased_most(date) if date else {"error": "Invalid date format"}
    else:
        return {"error": "Query not understood"}

# Helper to extract date
def extract_date(tokens):
    for token in tokens:
        try:
            return datetime.strptime(token, "%d%b%Y").date()
        except ValueError:
            continue
    return None


def get_stock_increased_most(date):
    conn = connect_to_db()
    cursor = conn.cursor(dictionary=True)
    try:
        print(f"""
            SELECT s.stock_name, MAX(t.transaction_price)- MIN(t.transaction_price) AS price_diff 
            FROM stock_details s JOIN stock_transactions t ON s.stock_id = t.stock_id 
            WHERE DATE(t.transaction_time) <= '{date}' GROUP BY s.stock_id ORDER BY price_diff DESC
            LIMIT 1;
        """)
        cursor.execute(f"""
            SELECT s.stock_name, MAX(t.transaction_price)- MIN(t.transaction_price) AS price_diff 
            FROM stock_details s JOIN stock_transactions t ON s.stock_id = t.stock_id 
            WHERE DATE(t.transaction_time) <= '{date}' GROUP BY s.stock_id ORDER BY price_diff ASC
            LIMIT 1;""")
        result = cursor.fetchone()
        return result or {"message": "No data available"}
    finally:
        conn.close()

def get_most_traded_stock(period):
    conn = connect_to_db()
    cursor = conn.cursor(dictionary=True)
    time_condition = f">= NOW() - INTERVAL 1 {'MONTH' if period == 'month' else 'WEEK'}"
    
    try:
        cursor.execute(f"""
            SELECT s.stock_name, SUM(t.transaction_volume) AS total_volume
            FROM stock_details s
            JOIN stock_transactions t ON s.stock_id = t.stock_id
            WHERE t.transaction_time {time_condition}
            GROUP BY s.stock_id
            ORDER BY total_volume DESC
            LIMIT 1;
        """)
        result = cursor.fetchone()
        return result or {"message": "No data available"}
    finally:
        conn.close()

def get_not_traded_stocks(period):
    conn = connect_to_db()
    cursor = conn.cursor(dictionary=True)
    
    time_condition = f">= NOW() - INTERVAL 1 {'WEEK' if period == 'week' else 'MONTH'}"
    
    try:
        print(f"""
            SELECT stock_id
                FROM stock_details
                WHERE stock_id NOT IN (
                    SELECT stock_id
                    FROM stock_transactions
                    WHERE transaction_time {time_condition}
                );
        """)
        cursor.execute(f"""
            SELECT stock_id
                FROM stock_details
                WHERE stock_id NOT IN (
                    SELECT stock_id
                    FROM stock_transactions
                    WHERE transaction_time {time_condition}
                );
        """)
        results = cursor.fetchall()
        return results or {"message": "all stocks are traded"}
    finally:
        conn.close()

def get_stock_decreased_most(date):
    conn = connect_to_db()
    cursor = conn.cursor(dictionary=True)
    print(f"""
            SELECT s.stock_name, MAX(t.transaction_price)- MIN(t.transaction_price) AS price_diff 
            FROM stock_details s JOIN stock_transactions t ON s.stock_id = t.stock_id 
            WHERE DATE(t.transaction_time) <= '{date}' GROUP BY s.stock_id ORDER BY price_diff DESC
            LIMIT 1;""")
    try:
        cursor.execute(f"""
            SELECT s.stock_name, MAX(t.transaction_price)- MIN(t.transaction_price) AS price_diff 
            FROM stock_details s JOIN stock_transactions t ON s.stock_id = t.stock_id 
            WHERE DATE(t.transaction_time) <= '{date}' GROUP BY s.stock_id ORDER BY price_diff DESC
            LIMIT 1;""")
        result = cursor.fetchone()
        return result or {"message": "No data available"}
    finally:
        conn.close()

@app.route("/query", methods=["POST"])
def query():
    user_query = request.json.get("query", "")
    response = parse_query(user_query)
    return jsonify(response)

if __name__ == "__main__":
    app.run(debug=True)
